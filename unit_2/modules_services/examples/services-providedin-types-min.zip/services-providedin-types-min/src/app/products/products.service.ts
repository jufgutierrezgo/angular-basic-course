// src/app/products/products.service.ts
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })   // ← antes: 'root'
export class ProductsService {
  private id = Math.random().toString(36).slice(2, 7);
  private items = ['Laptop', 'Smartphone', 'Headphones'];

  constructor() {
    console.log(`[ProductsService] instancia creada: ${this.id}`);
  }

  getId() { return this.id; }
  getProducts(): string[] { return [...this.items, `ServiceID:${this.id}`]; }
}
