// src/app/products/products.page.ts
import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductsService } from './products.service';

@Component({
  selector: 'app-products-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <h2>Products</h2>
    <p>ID servicio en Products: {{ id }}</p>
    <ul>
      <li *ngFor="let p of products">{{ p }}</li>
    </ul>
  `,
})
export class ProductsPage {
  private svc = inject(ProductsService);
  id = this.svc.getId();
  products = this.svc.getProducts();
}
