// src/app/home.component.ts
import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductsService } from './products/products.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule],
  template: `
    <h2>Home</h2>
    <p>ID servicio en Home: {{ id }}</p>
    <ul>
      <li *ngFor="let p of products">{{ p }}</li>
    </ul>
  `,
})
export class HomeComponent {
  private svc = inject(ProductsService);
  id = this.svc.getId();
  products = this.svc.getProducts();
}
