import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'platform' })
export class LoggerService {
  private id = Math.random().toString(36).slice(2, 7);
  private logs: string[] = [];

  constructor() {
    console.log(`[LoggerService @platform] instancia única: ${this.id}`);
  }

  add(msg: string) {
    const line = `${new Date().toLocaleTimeString()} · ${msg} · svc:${this.id}`;
    this.logs.push(line);
    console.log(line);
  }

  getAll() {
    return [...this.logs];
  }

  getId() {
    return this.id;
  }
}
