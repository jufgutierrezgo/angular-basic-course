import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoggerService } from './logger.service';

@Component({
  selector: 'app-a-root',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section style="border:1px solid #ccc; padding:12px; margin:8px;">
      <h2>App A</h2>
      <p><strong>Service ID (platform):</strong> {{ id }}</p>
      <button (click)="log()">Add log from A</button>
      <p><strong>Total logs compartidos:</strong> {{ logs.length }}</p>
      <ul>
        <li *ngFor="let l of logs">{{ l }}</li>
      </ul>
    </section>
  `,
})
export class AppAComponent {
  private logger = inject(LoggerService);
  id = this.logger.getId();
  logs = this.logger.getAll();

  log() {
    this.logger.add('Mensaje desde App A');
    this.logs = this.logger.getAll();
  }
}
