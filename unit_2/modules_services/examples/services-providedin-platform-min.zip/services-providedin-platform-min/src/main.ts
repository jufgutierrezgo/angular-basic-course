import { bootstrapApplication } from '@angular/platform-browser';
import { AppAComponent } from './app/app-a.component';
import { AppBComponent } from './app/app-b.component';

// Se montan dos aplicaciones Angular distintas en la misma página.
// Debido a providedIn: 'platform', ambas comparten UNA sola instancia del servicio.
bootstrapApplication(AppAComponent).catch(err => console.error(err));
bootstrapApplication(AppBComponent).catch(err => console.error(err));
